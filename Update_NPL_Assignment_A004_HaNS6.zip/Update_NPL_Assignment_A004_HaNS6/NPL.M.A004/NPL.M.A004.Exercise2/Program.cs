﻿using System;
using System.Text.RegularExpressions;

namespace NPL.M.A004.Exercise2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Khai bao 
            string email = string.Empty;

            // tien hanh check email
            while (CheckedEmail(email) != true)
            {
                // tien hanh nhap email
                Console.Write("Input your email: ");
                email = Console.ReadLine();

                // check email 
                if (CheckedEmail(email) != true)
                {
                    Console.WriteLine("Mail not invalid");
                }
                
            }
            if (CheckedEmail(email) == true)
            {
                Console.WriteLine("Mail invalid!!!");
            }

            Console.ReadKey();
        }

        private static bool CheckedEmail(string email)
        {
            // Khai bao
            string characterEmail = @"[a-zA-Z0-9._]+@(fsoft.com.vn|fpt.com.vn|outlook.com)";

            // Call regex
            Regex regex = new Regex(characterEmail);

            
            // match regex
            Match match = regex.Match(email);

            // check
            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }  
}

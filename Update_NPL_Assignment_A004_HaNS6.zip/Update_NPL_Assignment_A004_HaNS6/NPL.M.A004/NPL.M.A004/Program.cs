﻿using System;

namespace NPL.M.A004.Exercise1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Khai bao
            Program prg = new Program();
            string name = string.Empty;

            // Nhap ten
            Console.WriteLine("Input name: ");
            name = Console.ReadLine();

            // Format lai ten
            prg.NormalizeName(name);

            Console.ReadKey();
        }

        private void NormalizeName(string name)
        {
            // loai bo cac ky tu thua dau va vuoi, chuyen cac ky tu ve dang thuong
            name = name.ToLower().Trim();

            while(name.IndexOf("  ") != -1)
            {
                if (!name.Contains("  "))
                {
                    // loai bo 1 trong 2 dau cach 
                    name = name.Replace("  ", " ");
                }
            }

            // tiep do viet hoa cac vi tri phan tach tem
            // tach tung ky tu de xu ly viet hoa
            string[] item = name.Split(' '); 
            string afterFormat = string.Empty;

            for (int i = 0; i < item.Length; ++i)
            {
                // lay ra ky tu dau
                string first = item[i].Substring(0, 1);
                // lay ra ky tu sau chuoi
                string another = item[i].Substring(1, item[i].Length - 1);

                // tao chuoi voi ky tu viet hoa chu cai dau tien
                afterFormat += first.ToUpper() + another + " ";
            }
            // xoa dau cach o cuoi 
            afterFormat = afterFormat.Remove(afterFormat.LastIndexOf(' '), 1);
            // chuoi sau khi chuan hoa 
            Console.WriteLine($"Chuoi sau khi chuan hoa: {afterFormat}");
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NPL.M.A004.Exercise3
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Khai bao bien
            Program prg = new Program();
            // Khai bao so luong phan tu
            int quanity;
            Console.Write("Input Numbers element: ");
            while (int.TryParse(Console.ReadLine(), out quanity))
            {
                break;
            }
            // Khai bao mang
            string[] fullName = new string[quanity];

            //Tien hanh nhap danh sach ten
            for (int i = 0; i < fullName.Length; i++)
            {
                Console.WriteLine($"Input order names {i + 1}: ");
                // Nhap first name
                Console.Write("\t Input Name: ");
                fullName[i] = Console.ReadLine();

            }

            //return array List
            string[] ListNames = prg.SortLastName(fullName);
            var result = string.Join(", ", ListNames);
            Console.WriteLine(result);

            Console.ReadKey();
        }

        /// <summary>
        ///     Sort an array by last name
        /// </summary>
        /// <param name="arr"></param>
        /// <returns></returns>
        private string[] SortLastName(string[] arr)
        {
            // Goi chuoi thu nhat
            for (int i = 0; i < arr.Length; i++)
            {
                string lastName1 = arr[i].Split(' ')[arr[i].Split(' ').Length - 1];
                //Goi chuoi thu hai
                for (int j = i + 1; j < arr.Length; j++)
                {
                    string lastName2 = arr[j].Split(' ')[arr[j].Split(' ').Length - 1];
                    // So sanh xem co bi chenh lech ko
                    if (arr[i].CompareTo(arr[j]) > 0)
                    {
                        // Tien hanh hoan doi
                        string temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }

            }
            return arr;
        }
    }
}
